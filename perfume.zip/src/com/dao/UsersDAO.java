package com.dao;

import com.po.Users;
//�û��߼���
public class UsersDAO {
	//�û���¼����
	public boolean usersLogin(Users u)
	{
		if("Marry".equals(u.getUsername())&&"123".equals(u.getPassword()))
		{
			return true;
		}
		else 
		{
			return false;
		}
		
	}
}
