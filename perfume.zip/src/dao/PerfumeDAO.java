package dao;
//��Ʒҵ���߼���

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import entity.perfume;
import util.DBHelper;

public class PerfumeDAO {
	//������е���Ʒ��Ϣ
	public ArrayList<perfume> getAllperfume()
	{
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		ArrayList<perfume> list=new ArrayList<perfume>();//��Ʒ����
		try 
		{
			conn=DBHelper.getConnection();
			String sql="select * from perfume";//SQL���
			stmt=conn.prepareStatement(sql);
			rs=stmt.executeQuery();
			while(rs.next())
			{
				perfume per=new perfume();
				per.setId(rs.getInt("id"));
				per.setName(rs.getString("name"));
				per.setEngname(rs.getString("engname"));
				per.setBrand(rs.getString("brand"));
				per.setPrice(rs.getDouble("price"));
				per.setPhoto(rs.getString("photo"));
				per.setDesc(rs.getString("desc"));
				per.setStock(rs.getInt("stock"));
				list.add(per);//��һ����Ʒ���뼯��
			}
			return list;//���ؼ���
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
			// TODO: handle exception
		}
		finally
		{
			//�ͷ����ݼ�����
			if(rs!=null)
			{
				try
				{
					rs.close();
					rs=null;
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			//�ͷ�������
			if(stmt!=null)
			{
				try
				{
					stmt.close();
					stmt=null;
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
	
	}
	
	
	//������Ʒ��Ż����Ʒ����
	public perfume getPerfumeById(int id)
	{
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		try 
		{
			conn=DBHelper.getConnection();
			String sql="select * from perfume where id=?;";//SQL���
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1,id);
			rs=stmt.executeQuery();
			if(rs.next())
			{
				perfume per=new perfume();
				per.setId(rs.getInt("id"));
				per.setName(rs.getString("name"));
				per.setEngname(rs.getString("engname"));
				per.setBrand(rs.getString("brand"));
				per.setPrice(rs.getDouble("price"));
				per.setPhoto(rs.getString("photo"));
				per.setDesc(rs.getString("desc"));
				per.setStock(rs.getInt("stock"));
				return per;
			}
			else 
			{
				return null;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
			// TODO: handle exception
		}
		finally
		{
			//�ͷ����ݼ�����
			if(rs!=null)
			{
				try
				{
					rs.close();
					rs=null;
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			//�ͷ�������
			if(stmt!=null)
			{
				try
				{
					stmt.close();
					stmt=null;
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
	}
}
